document.getElementById('sendTip').addEventListener('click', async () => {
    const seedPhrase = document.getElementById('seedPhrase').value;
    const amount = document.getElementById('amount').value;
    if (!seedPhrase || !amount) {
        alert("Please fill all fields.");
        return;
    }

    // You would need to handle the wallet creation and transaction sending here
    console.log(`Sending ${amount} XRP...`);
});
