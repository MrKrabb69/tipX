chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.url && tab.url.includes("twitter.com") && changeInfo.status === "complete") {
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            function: checkTwitterProfile
        }, (results) => {
            if (results[0].result.username) {
                const username = results[0].result.username;
                fetch(`http://yourapi.com/getWallet/${username}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.walletAddress) {
                            // Store the wallet address in Chrome storage or handle as needed
                            chrome.storage.local.set({[username]: data.walletAddress});
                        }
                    })
                    .catch(error => console.error('Error fetching wallet address:', error));
            }
        });
    }
});

function checkTwitterProfile() {
    chrome.runtime.sendMessage({message: "isProfilePage"}, function(response) {
        return {username: response.username};
    });
}
